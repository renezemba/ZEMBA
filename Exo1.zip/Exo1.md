# TP1 sur le fondement de l'apprentissage autromatique

Ce TP1 permet d'apprendre les pérquis le fondement de l'apprentissage supervisé et non supervisé


```python
# Importation des bilbiothèques
import numpy as np
import matplotlib.pyplot as plt
```


```python
# Création de matrice
x=np.linspace(0,4,100)
y= np.sin(x)
z=np.cos(x)
z.shape
```




    (100,)




```python
# répresentation de la fonction sinus
line, = plt.plot(x,y)
line.set_label('sinus')
plt.ylabel('some numbers')
plt.legend()
plt.show()
```


    
![png](output_4_0.png)
    



```python
# Représentation de la fonction cosinus
line, =plt.plot(x,z)
line.set_label('cos')
plt.ylabel('some numbers')
plt.legend()
plt.show()
```


    
![png](output_5_0.png)
    



```python
# Réprentation des deux fonctions sinus et cosinus dans le même repère 
line1,line2, = plt.plot(x,y,x,z,)
plt.ylabel('some numbers')
line1.set_label('sinus')
line2.set_label('cosinus')
plt.legend()
plt.title('Graphes trigonométriques')
plt.show()
```


    
![png](output_6_0.png)
    



```python
# Répresentation de la fonction sur plusieurs graphiques contigue en trait plein, en des traits séparés et points 
plt.figure(1)
plt.subplot(131)
plt.plot(x,y)
plt.subplot(132)
plt.plot(x,y,'r--')
plt.subplot(133)
plt.plot(x,y,'go')
plt.show()
```


    
![png](output_7_0.png)
    



```python
# Définition d'une matrice d'ordre 5 de valeurs comprises entre 0 et 1
import numpy.random as rd
A = rd.rand(5,5)
A
```




    array([[0.53460635, 0.96358048, 0.9653501 , 0.61119014, 0.49164347],
           [0.38440474, 0.71148533, 0.56544321, 0.1403737 , 0.28016261],
           [0.89530212, 0.06655135, 0.93816372, 0.15484993, 0.58337941],
           [0.82754163, 0.06574847, 0.03483723, 0.8047766 , 0.90120036],
           [0.38287891, 0.64608872, 0.42147336, 0.70896682, 0.22860977]])



# Fin de l'atelier de TP
